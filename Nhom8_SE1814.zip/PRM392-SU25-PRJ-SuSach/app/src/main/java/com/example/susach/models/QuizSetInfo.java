package com.example.susach.models;

public class QuizSetInfo {
    public String name;
    public int quizCount;

    public QuizSetInfo(String name, int quizCount) {
        this.name = name;
        this.quizCount = quizCount;
    }
} 